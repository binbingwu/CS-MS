package com.example.q1;

public class task {
    private String Title;
    private String effortEstimate;

    public task(String Title, String effortEstimate) {
        this.Title = Title;
        this.effortEstimate = effortEstimate;
    }

    public void setEffortEstimate(String effortEstimate) {
        this.effortEstimate = effortEstimate;
    }

    public String getEffortEstimate() {
        return effortEstimate;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }


}
