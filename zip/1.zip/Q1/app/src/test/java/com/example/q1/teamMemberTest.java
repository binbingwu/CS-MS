package com.example.q1;
//import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

public class teamMemberTest {
    @Test
    void testTeamMember(){
        teamMember teamMember=new teamMember("name","live");
        assertTrue(teamMember.getTasks()=="live");
    }
}
