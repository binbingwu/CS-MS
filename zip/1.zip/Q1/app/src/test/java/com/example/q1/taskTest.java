package com.example.q1;

//import org.junit.Test;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class taskTest {
    @Test
    void testTask(){
        task task = new task("live","1day");
        assertTrue(task.getTitle()=="live");
    }
}
