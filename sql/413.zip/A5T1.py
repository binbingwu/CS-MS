import sqlite3
import csv 
import itertools

connection = None
cursor = None

def connect(path):
    global connection, cursor

    connection = sqlite3.connect(path)    
    cursor = connection.cursor()    
    cursor.execute(' PRAGMA foreign_keys=ON; ')   
    connection.commit()
    return

def csvtodb():
	global connection,cursor
	
	path = 'A5.db'
	connect(path)
	cursor.execute('DROP TABLE IF EXISTS LISTINGS;')	
	cursor.execute('DROP TABLE IF EXISTS REVIEWS;')	
	cursor.execute('CREATE TABLE LISTINGS(id INT PRIMARY KEY,name TEXT,host_id INT,host_name TEXT,neighbourhood TEXT,room_type TEXT,price INT,minimum_nights INT,availability_365 INT);')	
	cursor.execute('CREATE TABLE REVIEWS(listing_id INT,id INT PRIMARY KEY,date TEXT,reviewer_id INT,reviewer_name TEXT,comments TEXT);')	
	csvfile = open('YVR_Airbnb_listings_summary.csv','r',encoding='utf-8')
	csvlist = csv.reader(csvfile)
	for item in itertools.islice(csvlist,1,None):
		connection.execute('INSERT INTO LISTINGS (id,name,host_id,host_name,neighbourhood,room_type,price,minimum_nights,availability_365) VALUES (?,?,?,?,?,?,?,?,?)',\
		item)
	csvfile.close()
	connection.commit()	
	csvfile = open('YVR_Airbnb_reviews.csv','r',encoding='utf-8')
	csvlist = csv.reader(csvfile)
	for item in itertools.islice(csvlist,1,None):
		connection.execute('INSERT INTO REVIEWS (listing_id,id,date,reviewer_id,reviewer_name,comments) VALUES (?,?,?,?,?,?)',\
		item)
	csvfile.close()
	connection.commit()
	connection.close()	
	return    

def main():
	   
	csvtodb()
	return

if __name__ == "__main__":
    main()
