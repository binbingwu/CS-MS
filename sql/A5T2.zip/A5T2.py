import csv 
import pymongo 
listid = []
listrev = []
temp = []
def csvtodb():	
	client = pymongo.MongoClient("mongodb://localhost:27017/")
	db = client["A5db"]
	list_con = db["listings"]
	collist = db.list_collection_names()
	if "listings"  in collist:
		print("The collection exists.")
	csvlisting = open('YVR_Airbnb_listings_summary.csv','r',encoding='utf-8')
	csvreviews = open('YVR_Airbnb_reviews.csv','r',encoding='utf-8')
	
	reader = csv.reader(csvlisting)
	fieldnames = next(reader)
	csv_reader = csv.DictReader(csvlisting,fieldnames=fieldnames) 
	for row in csv_reader:
		d = {}
		for k,v in row.items():
			d[k]=v
		listid.append(d)		
	reader = csv.reader(csvreviews)
	fieldnames = next(reader)
	csv_reader = csv.DictReader(csvreviews,fieldnames=fieldnames) 
	for row in csv_reader:
		d = {}
		for k,v in row.items():
			d[k]=v
		listrev.append(d)
	d1 = {}	    
	for i in listid:
		for j in listrev:
			if j["listing_id"] == i["id"]:
				temp.append(j)
		d1.clear()
		d1.update(i)
		d1["reviews"] = temp		
		list_con.insert_one(d1)
		temp.clear()
	csvlisting.close()
	csvreviews.close()	
	return   

def main():	   
	csvtodb()
	return

if __name__ == "__main__":
    main()
